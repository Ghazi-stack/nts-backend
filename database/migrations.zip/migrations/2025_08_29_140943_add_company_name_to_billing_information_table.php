<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('billing_information', function (Blueprint $table) {
            $table->string('company_name')->nullable()->after('last_name');
        });
    }

    public function down()
    {
        Schema::table('billing_information', function (Blueprint $table) {
            $table->dropColumn('company_name');
        });
    }
};
